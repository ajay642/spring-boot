package com.luv2code.springboot.cruddemo.dao;

import java.util.List;

import javax.persistence.EntityManager;

import org.hibernate.Session;
import org.hibernate.query.Query;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

import com.luv2code.springboot.cruddemo.entity.Employee;

@Repository
public class EmployeeDAOHibernate implements EmployeeDAO {

	// declare the entitymanager field
	EntityManager entityManager;

	@Autowired
	public EmployeeDAOHibernate(EntityManager theEntityManager) {
		entityManager = theEntityManager;

	}

	@Override
	public List<Employee> findAll() {

		// get the hiberate session
		Session session = entityManager.unwrap(Session.class);

		// create the query
		Query<Employee> theQuery = session.createQuery("from Employee", Employee.class);

		// get the employee list
		List<Employee> theList = theQuery.getResultList();

		// return the list

		return theList;
	}

	@Override
	public Employee findById(int id) {

		// get the hibernate session
		Session session = entityManager.unwrap(Session.class);

		// get the Employee from the session
		Employee theEmployee = session.get(Employee.class, id);

		return theEmployee;
	}

	@Override
	public void save(Employee employee) {
		// get the hibernate session
		Session session = entityManager.unwrap(Session.class);

		// get the Employee from the session
		session.saveOrUpdate(employee);

	}

	@Override
	public void delete(int theEmployeeId) {

		// get the hiberate session
		Session session = entityManager.unwrap(Session.class);

		// create the query
		Query theQuery = session.createQuery("delete from Employee where id=:employeeId");
		
		theQuery.setParameter("employeeId", theEmployeeId);
		
		theQuery.executeUpdate();
		
	}

}
